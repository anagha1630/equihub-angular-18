
// vesting-schedule.component.ts
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TabService } from '../../services/tab.service';

interface VestingItem {
  slNo: number;
  symbol: string;
  type: string;
  awardPrice: number;
  granted: number;
  exercisable: number;
  finalExerciseDate: string;
  unvestedMarketValue: number;
  exercisableMarketValue: number;
}

@Component({
  selector: 'app-vesting-schedule',
  templateUrl: './vesting-schedule.component.html',
  styleUrls: ['./vesting-schedule.component.scss']
})
export class VestingScheduleComponent implements OnInit {
  vestingData: VestingItem[] = [
    { 
      slNo: 1, 
      symbol: 'IBM', 
      type: 'RSU', 
      awardPrice: 10, 
      granted: 100, 
      exercisable: 25, 
      finalExerciseDate: '21/06/2025', 
      unvestedMarketValue: 75, 
      exercisableMarketValue: 250 
    },
    { 
      slNo: 2, 
      symbol: 'IBM', 
      type: 'RSU', 
      awardPrice: 10, 
      granted: 100, 
      exercisable: 6, 
      finalExerciseDate: '21/06/2026', 
      unvestedMarketValue: 69, 
      exercisableMarketValue: 60 
    },
    { 
      slNo: 3, 
      symbol: 'IBM', 
      type: 'ESOP', 
      awardPrice: 10, 
      granted: 100, 
      exercisable: 6, 
      finalExerciseDate: '21/06/2027', 
      unvestedMarketValue: 63, 
      exercisableMarketValue: 60 
    },
    { 
      slNo: 4, 
      symbol: 'IBM', 
      type: 'ESOP', 
      awardPrice: 10, 
      granted: 100, 
      exercisable: 6, 
      finalExerciseDate: '21/06/2028', 
      unvestedMarketValue: 57, 
      exercisableMarketValue: 60 
    },
    { 
      slNo: 5, 
      symbol: 'IBM', 
      type: 'ESOP', 
      awardPrice: 10, 
      granted: 100, 
      exercisable: 7, 
      finalExerciseDate: '21/06/2029', 
      unvestedMarketValue: 50, 
      exercisableMarketValue: 70 
    }
  ];

  tooltips = {
    slNo: 'Serial Number of the vesting item',
    symbol: 'Stock symbol identifier',
    type: 'Type of equity compensation',
    awardPrice: 'The price at which the equity was granted',
    granted: 'Number of shares granted',
    exercisable: 'Number of shares that can be exercised',
    finalExerciseDate: 'Last date to exercise the options',
    unvestedMarketValue: 'Current market value of unvested shares',
    exercisableMarketValue: 'Current market value of exercisable shares'
  };
  //tabService: any;

  constructor(
    private router: Router,
    private tabService: TabService
  ) { }

  ngOnInit(): void {
  }

  navigateTo(type: string): void {
    console.log(`Navigating to type: ${type}`); // Add this for debugging
    
    // First set the active tab
    this.tabService.setActiveTab(type);
    
    // Add a small delay before navigation to ensure tab is set
    setTimeout(() => {
      if (type === 'RSU') {
        console.log('Navigating to RSU tab');
      } else if (type === 'ESOP') {
        console.log('Navigating to ESOP tab');
      }
    }, 100);
  }

  showTooltip(tooltip: string): void {
    console.log(`Showing tooltip: ${tooltip}`);
  }
}