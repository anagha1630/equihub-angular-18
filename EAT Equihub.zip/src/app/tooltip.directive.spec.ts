import { TooltipDirective } from './tooltip.directive';

describe('TooltipDirective', () => {
  it('should create an instance', () => {
    const directive = new TooltipDirective();
    expect(directive).toBeTruthy();
  });
});
